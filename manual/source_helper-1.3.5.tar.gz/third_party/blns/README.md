Copied at
https://github.com/minimaxir/big-list-of-naughty-strings/blob/894882e7d1f3f2383aa472fdce4a80b8cd256df4/blns.json

Commit date: May 25, 2020
Copied date: March 25, 2021
