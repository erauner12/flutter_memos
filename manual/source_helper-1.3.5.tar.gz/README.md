Utilities to help with Dart source code generation.

[![Pub package](https://img.shields.io/pub/v/source_helper.svg)](https://pub.dev/packages/source_helper)
[![Build Status](https://github.com/google/source_helper.dart/workflows/Dart/badge.svg?branch=main)](https://github.com/google/source_helper.dart/actions?query=workflow%3A%22Dart%22+branch%3Amain)
[![package publisher](https://img.shields.io/pub/publisher/source_helper.svg)](https://pub.dev/packages/source_helper/publisher)

## Contributing

See [`CONTRIBUTING.md`](CONTRIBUTING.md) for details.

## License

Apache 2.0; see [`LICENSE`](LICENSE) for details.

## Disclaimer

This project is not an official Google project. It is not supported by
Google and Google specifically disclaims all warranties as to its quality,
merchantability, or fitness for a particular purpose.
